pir_07_04_1_person			A desktop between 1 and 2	A leaves after B enters 
							B between 3,4,5and 6	
pir_07_04_1_person_1		A between 3,4,5and 6	
							may have some interruption with 2 or 3 ppl	
pir_07_04_1_ppl_data_1		A between 4 and 6	
			
pir_08_04_1_person_data			A between 1,2,3 and 4	
pir_08_04_1_person_data_1		A between 1,2,3 and 4	
pir_08_04_1_person_data_2		A below 1 working on the desktop	
pir_08_04_1_person_data_3		A below 1 working on the desktop	
pir_08_04_1_person_data_4		A below 1 working on the desktop	